package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AudioGreen
import com.example.ui.theme.StudioCobalt

import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Speed

data class ToolCardInfo(
    val id: Int,
    val title: String,
    val subtitle: String,
    val description: String,
    val icon: ImageVector,
    val badge: String,
    val tagColor: Color,
    val testTag: String
)

@Composable
fun HomeScreen(
    historyCount: Int,
    onNavigateToTool: (Int) -> Unit
) {
    val tools = listOf(
        ToolCardInfo(
            id = 1, // Conversor
            title = "Conversor de Formatos",
            subtitle = "MP3, WAV, AAC, FLAC, OGG, M4A",
            description = "Transforma tus archivos de audio con ajuste de bitrate, frecuencias de muestreo, estéreo/mono, recorte con onda de audio y ganancia de volumen.",
            icon = Icons.Default.SwapHoriz,
            badge = "Herramienta Principal",
            tagColor = StudioCobalt,
            testTag = "tool_card_converter"
        ),
        ToolCardInfo(
            id = 2, // Extractor de Video
            title = "Extractor de Audio de Video",
            subtitle = "MP4, MKV, WEBM, 3GP -> MP3, AAC, WAV",
            description = "Extrae y decodifica flujos de audio directamente desde archivos de video para obtener pistas musicales, bandas sonoras o notas de voz.",
            icon = Icons.Default.Movie,
            badge = "Nuevo Módulo",
            tagColor = Color(0xFFFF9800),
            testTag = "tool_card_video_extractor"
        ),
        ToolCardInfo(
            id = 3, // Cambiador Velocidad y Tono
            title = "Cambiador de Velocidad y Tono",
            subtitle = "Velocidad 0.5x-2.5x • Tono -12a+12 Semitonos",
            description = "Acelera o ralentiza la reproducción de audio y ajusta la afinación musical sin perder calidad con remuestreo PCM en tiempo real.",
            icon = Icons.Default.Speed,
            badge = "Efectos DSP",
            tagColor = Color(0xFF7C4DFF),
            testTag = "tool_card_speed_pitch"
        ),
        ToolCardInfo(
            id = 4, // Presets
            title = "Presets de Audio Studio",
            subtitle = "Configuraciones preestablecidas de 1 toque",
            description = "Aplica ajustes optimizados para Música de Alta Fidelidad (MP3 320k), Voz & Podcast (AAC 96k), Calidad Estudio Sin Pérdidas (WAV/FLAC) y Apple AAC.",
            icon = Icons.Default.Tune,
            badge = "Acceso Rápido",
            tagColor = Color(0xFF00B0FF),
            testTag = "tool_card_presets"
        ),
        ToolCardInfo(
            id = 5, // Mis Archivos
            title = "Mis Archivos Convertidos",
            subtitle = "Ubicación: /Music/AudioLabs/convert",
            description = "Explora, reproduce y administra tu biblioteca de audios convertidos y extraídos. Guardados automáticamente en las subcarpetas de AudioLabs.",
            icon = Icons.Default.FolderZip,
            badge = "$historyCount Archivos",
            tagColor = AudioGreen,
            testTag = "tool_card_history"
        ),
        ToolCardInfo(
            id = 6, // Inspector
            title = "Inspector & Analizador",
            subtitle = "Metadatos Técnicos y Parámetros PCM",
            description = "Examina la estructura interna de cualquier pista de audio: tasa de muestreo, profundidad de bits, códecs de decodificación y canales estéreo/mono.",
            icon = Icons.Default.Analytics,
            badge = "Análisis Técnico",
            tagColor = Color(0xFFEC407A),
            testTag = "tool_card_inspector"
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Studio Welcome Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                StudioCobalt.copy(alpha = 0.15f),
                                Color(0xFF7C4DFF).copy(alpha = 0.12f)
                            )
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(StudioCobalt),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "AudioLabs Studio",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Menú Principal de Herramientas",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            shape = CircleShape,
                            color = StudioCobalt.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "v2.0 Native",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = StudioCobalt,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Selecciona una herramienta para comenzar. Cada sección funciona como un módulo independiente para procesar tu música y grabaciones.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Subfolder Access Info Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(AudioGreen.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SdCard,
                        contentDescription = "Storage",
                        tint = AudioGreen,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Carpeta Automática de Salida",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Tus audios se guardan en: /Music/AudioLabs/convert (Acceso directo sin entrar a Android/data)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Herramientas Disponibles",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Render Tool Cards
        tools.forEach { tool ->
            ToolCardItem(
                tool = tool,
                onClick = { onNavigateToTool(tool.id) }
            )
            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}

@Composable
fun ToolCardItem(
    tool: ToolCardInfo,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(tool.testTag)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(tool.tagColor.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = tool.icon,
                            contentDescription = tool.title,
                            tint = tool.tagColor,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = tool.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = tool.subtitle,
                            style = MaterialTheme.typography.labelMedium,
                            color = tool.tagColor
                        )
                    }
                }

                Surface(
                    shape = CircleShape,
                    color = tool.tagColor.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = tool.badge,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = tool.tagColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = tool.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = tool.tagColor.copy(alpha = 0.1f),
                    modifier = Modifier.clip(RoundedCornerShape(10.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Abrir Herramienta",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = tool.tagColor
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = tool.tagColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
